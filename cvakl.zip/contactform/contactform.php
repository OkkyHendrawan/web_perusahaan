<?php
// Set header CORS untuk izin akses dari semua domain
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token");

// Konfigurasi penerima email
$to_email = "legal.arnandakarya@gmail.com"; // Ganti dengan alamat email yang dituju
$subject = "Pesan dari Formulir Kontak";

// Ambil data dari formulir
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// Bangun pesan email
$body = "Nama: $name\n";
$body .= "Email: $email\n\n";
$body .= "Pesan:\n$message";

// Set header email
$headers = "From: $email";

// Kirim email
$mail_sent = mail($to_email, $subject, $body, $headers);

// Cek apakah email berhasil terkirim
if ($mail_sent) {
    echo 'OK'; // Jika berhasil terkirim, kirim respons 'OK' kembali ke JavaScript
} else {
    echo 'Pesan tidak dapat dikirim. Mohon coba lagi nanti.'; // Jika gagal terkirim, kirim pesan kesalahan kembali ke JavaScript
}
?>
