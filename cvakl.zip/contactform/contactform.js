jQuery(document).ready(function($) {
  "use strict";

  //Contact form
  $('form.contactForm').submit(function() {
    var f = $(this).find('.form-group'),
      ferror = false,
      emailExp = /^[^\s()<>@,;:\/]+@\w[\w\.-]+\.[a-z]{2,}$/i;

    f.children('input, textarea').each(function() { // Run through each input and textarea
      var i = $(this); // Current input
      var rule = i.attr('data-rule'); // Get rule for validation

      if (rule !== undefined) {
        var ierror = false; // Error flag for current input
        var pos = rule.indexOf(':', 0);
        if (pos >= 0) {
          var exp = rule.substr(pos + 1, rule.length);
          rule = rule.substr(0, pos);
        } else {
          rule = rule.substr(pos + 1, rule.length);
        }

        switch (rule) {
          case 'required':
            if (i.val() === '') {
              ferror = ierror = true;
            }
            break;

          case 'minlen':
            if (i.val().length < parseInt(exp)) {
              ferror = ierror = true;
            }
            break;

          case 'email':
            if (!emailExp.test(i.val())) {
              ferror = ierror = true;
            }
            break;
        }
        // Show validation message
        i.next('.validation').html((ierror ? (i.attr('data-msg') !== undefined ? i.attr('data-msg') : 'Wrong Input') : '')).show('blind');
      }
    });

    // If there are errors, stop form submission
    if (ferror) return false;
    else var str = $(this).serialize();

    // Send the form data using AJAX
    var action = $(this).attr('action');
    if (!action) {
      action = 'contactform/contactform.php'; // If action is not specified, set it to 'contactform.php'
    }

    $.ajax({
      type: "POST",
      url: action,
      data: str,
      success: function(msg) {
        if (msg == 'OK') {
          // If successful, show success message and clear the form
          $("#sendmessage").addClass("show");
          $("#errormessage").removeClass("show");
          $('.contactForm').find("input, textarea").val("");
        } else {
          // If not successful, show error message
          $("#sendmessage").removeClass("show");
          $("#errormessage").addClass("show");
          $('#errormessage').html(msg);
        }
      }
    });
    return false;
  });
});
